package com.tonnie.ipl.xpto.tracking.telemetry.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class MockConfig {

}