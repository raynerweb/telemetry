package com.tonnie.ipl.xpto.tracking.telemetry.enums;

public enum SensorType {

	ODOMETER,
	RPM,
	SPEED
	
	
}
