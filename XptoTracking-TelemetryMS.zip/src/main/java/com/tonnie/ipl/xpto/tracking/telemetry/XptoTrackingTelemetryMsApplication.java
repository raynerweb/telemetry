package com.tonnie.ipl.xpto.tracking.telemetry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XptoTrackingTelemetryMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(XptoTrackingTelemetryMsApplication.class, args);
	}

}
