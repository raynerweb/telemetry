package com.tonnie.ipl.xpto.tracking.telemetry.service;

import java.util.UUID;

import com.tonnie.ipl.xpto.tracking.telemetry.model.TelemetryProfile;

public interface ITelemetryProfileService extends IBaseEntityService<UUID, TelemetryProfile> {
  
  
  
}
