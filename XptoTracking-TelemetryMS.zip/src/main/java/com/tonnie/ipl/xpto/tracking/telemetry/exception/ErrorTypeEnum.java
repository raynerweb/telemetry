package com.tonnie.ipl.xpto.tracking.telemetry.exception;

public enum ErrorTypeEnum {
	PERSISTENCE,
	BUSINESS,
	COMMUNICATION,
	UNKNOWN;
}